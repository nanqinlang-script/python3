:orphan:

***************************************
Uploading Packages to the Package Index
***************************************

The contents of this page have moved to the section :ref:`package-index`.
